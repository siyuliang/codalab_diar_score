#!/usr/bin/env python
from __future__ import print_function
from __future__ import unicode_literals
import sys
import os
import os.path
import argparse
from tabulate import tabulate
from scorelib import __version__ as VERSION
from scorelib.argparse import ArgumentParser
from scorelib.rttm import load_rttm
from scorelib.turn import merge_turns, trim_turns
from scorelib.score import score
from scorelib.six import iterkeys
from scorelib.uem import gen_uem, load_uem
from scorelib.utils import error, info, warn, xor
import glob
import subprocess

"""Codalab scoring script for diarization outputs.

To evaluate system output stored in RTTM files ``sys1.rttm``, ``sys2.rttm``,
... against a corresponding reference diarization stored in RTTM files
``ref1.rttm``, ``ref2.rttm``, ...:

To run locally from the directory, make sure input_dir has reference rttms as in ref/*.rttm, 
and system output rttms as in res/*.rttm.

    python dscore/evaluate.py input_dir output_dir

Output diarization score is stored in output_dir/score.txt. 

"""


class RefRTTMAction(argparse.Action):
    """Custom action to ensure that reference files are specified from a
    script file or from the command line but not both.
    """
    def __call__(self, parser, namespace, values, option_string=None):
        setattr(namespace, self.dest, values)
        if not xor(namespace.ref_rttm_fns, namespace.ref_rttm_scpf):
            parser.error('Exactly one of -r and -R must be set.')


class SysRTTMAction(argparse.Action):
    """Custom action to ensure that system files are specified from a script
    file or from the command line but not both.
    """
    def __call__(self, parser, namespace, values, option_string=None):
        setattr(namespace, self.dest, values)
        if not xor(namespace.sys_rttm_fns, namespace.sys_rttm_scpf):
            parser.error('Exactly one of -s and -S must be set.')


def load_rttms(rttm_fns):
    """Load speaker turns from RTTM files.

    Parameters
    ----------
    rttm_fns : list of str
        Paths to RTTM files.

    Returns
    -------
    turns : list of Turn
        Speaker turns.

    file_ids : set
        File ids found in ``rttm_fns``.
    """
    turns = []
    file_ids = set()
    for rttm_fn in rttm_fns:
        if not os.path.exists(rttm_fn):
            error('Unable to open RTTM file: %s' % rttm_fn)
            sys.exit(1)
        try:
            turns_, _, file_ids_ = load_rttm(rttm_fn)
            turns.extend(turns_)
            file_ids.update(file_ids_)
        except IOError as e:
            error('Invalid RTTM file: %s. %s' % (rttm_fn, e))
            sys.exit(1)
    return turns, file_ids


def check_for_empty_files(ref_turns, sys_turns, uem):
    """Warn on files in UEM without reference or speaker turns."""
    ref_file_ids = {turn.file_id for turn in ref_turns}
    sys_file_ids = {turn.file_id for turn in sys_turns}
    for file_id in sorted(iterkeys(uem)):
        if file_id not in ref_file_ids:
            warn('File "%s" missing in reference RTTMs.' % file_id)
        if file_id not in sys_file_ids:
            warn('File "%s" missing in system RTTMs.' % file_id)
    # TODO: Clarify below warnings; this indicates that there are no
    #       ELIGIBLE reference/system turns.
    if not ref_turns:
        warn('No reference speaker turns found within UEM scoring regions.')
    if not sys_turns:
        warn('No system speaker turns found within UEM scoring regions.')


def load_script_file(fn):
    """Load file names from ``fn``."""
    with open(fn, 'rb') as f:
        return [line.decode('utf-8').strip() for line in f]


def main():
    input_dir = sys.argv[1]
    output_dir = sys.argv[2]
    # if not os.path.isdir(submit_dir):
    #     print ("it doesn't exist")
    subprocess.run(["ls", "-l", "-R"])
    subprocess.run(["chmod", "777", "-R", "./program/dscore"])
    subprocess.run(["ls", "-l", "-R"])

    submit_dir = os.path.join(input_dir, 'res')
    truth_dir = os.path.join(input_dir, 'ref')

    ref_paths = glob.glob(truth_dir + '/reference_data/*.rttm')
    res_paths = glob.glob(submit_dir + '/*.rttm')

    # dir_permissions = oct(os.stat(input_dir).st_mode)[-3:]
    # print(dir_permissions)

    # Load speaker/reference speaker turns and UEM. If no UEM specified,
    # determine it automatically.
    info('Loading speaker turns from reference RTTMs...', file=sys.stderr)
    ref_turns, _ = load_rttms(ref_paths)
    info('Loading speaker turns from system RTTMs...', file=sys.stderr)
    sys_turns, _ = load_rttms(res_paths)
    # if args.uemf is not None:
    #     info('Loading universal evaluation map...', file=sys.stderr)
    #     uem = load_uem(args.uemf)
    uem = gen_uem(ref_turns, sys_turns)

    # Trim turns to UEM scoring regions and merge any that overlap.
    info('Trimming reference speaker turns to UEM scoring regions...',
         file=sys.stderr)
    ref_turns = trim_turns(ref_turns, uem)
    info('Trimming system speaker turns to UEM scoring regions...',
         file=sys.stderr)
    sys_turns = trim_turns(sys_turns, uem)
    info('Checking for overlapping reference speaker turns...',
         file=sys.stderr)
    ref_turns = merge_turns(ref_turns)
    info('Checking for overlapping system speaker turns...',
         file=sys.stderr)
    sys_turns = merge_turns(sys_turns)

    # Score.
    info('Scoring...', file=sys.stderr)
    check_for_empty_files(ref_turns, sys_turns, uem)
    file_scores, global_scores = score(
        ref_turns, sys_turns, uem, step=0.010,
        jer_min_ref_dur=0.0, collar=0.0,
        ignore_overlaps=False)
    der_score = global_scores[1]
    print(der_score)
    # print(os.listdir('.'))

    if os.path.isdir(submit_dir) and os.path.isdir(truth_dir):
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        # print(len(ref_paths), ref_paths)

        output_filename = os.path.join(output_dir, 'scores.txt')
        output_file = open(output_filename, 'w')
        print(output_filename)
        output_file.write("DER:" + str(der_score))

        output_file.close()

if __name__ == '__main__':
    main()