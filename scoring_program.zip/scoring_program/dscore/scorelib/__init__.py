"""Diarization system scoring."""
__version__ = '1.1.0'
