import subprocess

subprocess.run(["ls", "-l"])